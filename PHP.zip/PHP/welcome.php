
<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;

}
require_once "config.php";
function abc(){
    echo htmlspecialchars($_SESSION["username"]);
    echo htmlspecialchars($_SESSION["id"]);
    echo $_POST['Title'];
    echo $_POST['Problem'];
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif;} /*text-align: center; }*/
        .containers{
            float:right;
            width: 100%;
            background: black;
            text-align:right;
        }
        .logout{
            float:right;
            margin-right:10px;
        }   
        
    </style>
</head>
<body>

    <div class="containers">    
        <p class="logout my-1">
            <a href="logout.php" class="btn btn-danger ml-3">Sign Out</a>
        </p>
        <p class="my-3" style="color:#dedede;">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</p>
        
    </div>
    <div class="container-fluid ">
        <h6 class="my-3" style="color:black;"><b>Name : <?php echo htmlspecialchars($_SESSION["username"]); ?></b></h6>

        <h6 class="my-3" style="color:black;"><b>Id : <?php echo htmlspecialchars($_SESSION["id"]); ?></b></h6>
    </div>
    <div class="container-sm w-50">
    <form action="" method="post">
            <div class="form-group">
                <label>Issue : </label>
                <input type="text" name="Title" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="">
                <span class="invalid-feedback"><?php echo $Title_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Describe : </label>
                <input type="text" name="Problem" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="">
                <span class="invalid-feedback"><?php echo $problem_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
            </div>
        </form>
    </div>
</body>
</html>